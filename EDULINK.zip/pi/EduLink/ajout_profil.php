<?php
// Inclure votre fichier de connexion à la base de données
include('sql.php');

// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les valeurs du formulaire
    $identifiant = $_POST["identifiant"];
    $mot_de_passe = $_POST["pswd"]; 
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $email = $_POST["mail"];
    $departement = $_POST["departement"];
    $universite = $_POST["universite"];

    // Valider et nettoyer les données
    $identifiant = filter_var($identifiant, FILTER_SANITIZE_STRING);
    $nom = filter_var($nom, FILTER_SANITIZE_STRING);
    $prenom = filter_var($prenom, FILTER_SANITIZE_STRING);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);

    // Effectuer des contrôles de saisie supplémentaires
    if (!preg_match("/^[a-zA-Z- -é-è]+$/", $nom)) {
        echo "Erreur : Le nom ne doit contenir que des lettres.";
        exit();
    }

    if (!preg_match("/^[a-zA-Z- -é-è]+$/", $prenom)) {
        echo "Erreur : Le prénom ne doit contenir que des lettres.";
        exit();
    }

    if (strlen($identifiant) != 10) {
        echo "Erreur : L'identifiant doit avoir une longueur de 10 caractères.";
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Erreur : L'adresse email n'est pas valide.";
        exit();
    }
            // Préparer la requête SQL d'insertion
            $query = "INSERT INTO enseignant (identifiant, mot_de_passe , nom, prenom, universite, departement , email) VALUES (?, ?,  ?, ?, ?, ?, ?)";

            // Préparer la déclaration SQL
            $statement = $mysqli->prepare($query);

            // Vérifier si la préparation de la requête a réussi
            if ($statement) {
                // Lier les paramètres
                $statement->bind_param("sssssss", $identifiant, $mot_de_passe, $nom, $prenom, $universite, $departement, $email);

                // Exécuter la requête
                if ($statement->execute()) {
                    header("Location: index.php");
                    exit();
                } else {
                    echo "Erreur lors de l'exécution de la requête : " . $statement->error;
                }

                // Fermer la déclaration
                $statement->close();
            } else {
                echo "Erreur de préparation de la requête : " . $mysqli->error;
            }
        } else {
            echo "Erreur lors du déplacement du fichier téléchargé.";
        }

    // Fermer la connexion à la base de données
    $mysqli->close();

?>
