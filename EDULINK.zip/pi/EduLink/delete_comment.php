<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['enseignant_id']) || empty($_SESSION['enseignant_id'])) {
    header("Location: authentification.html"); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    exit;
}

// Vérifier si les identifiants du commentaire et du forum sont passés dans l'URL
if (isset($_GET['id'], $_GET['forum_id'])) {
    $commentaire_id = intval($_GET['id']);
    $forum_id = intval($_GET['forum_id']);

    // Inclure le fichier de connexion à la base de données
    include('sql.php');

    // Récupérer l'identifiant de l'enseignant connecté
    $enseignant_id = $_SESSION['enseignant_id'];

    // Vérifier si l'utilisateur est l'auteur du commentaire
    $query = "SELECT enseignant FROM commentaire WHERE id_commentaire = $commentaire_id";
    $result = $mysqli->query($query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $comment_author_id = $row['enseignant'];

        if ($comment_author_id == $enseignant_id) {
            // L'utilisateur est autorisé à supprimer le commentaire
            // Suppression du commentaire de la base de données
            $delete_query = "DELETE FROM commentaire WHERE id_commentaire = $commentaire_id";
            $delete_result = $mysqli->query($delete_query);

            if ($delete_result) {
                // Rediriger l'utilisateur vers la page de détails du forum après la suppression
                header("Location: forum_détails.php?id=$forum_id");
                exit;
            } else {
                echo "Erreur lors de la suppression du commentaire.";
            }
        } else {
            // L'utilisateur n'est pas autorisé à supprimer ce commentaire
            echo "Vous n'êtes pas autorisé à supprimer ce commentaire.";
        }
    } else {
        // Commentaire non trouvé dans la base de données
        echo "Commentaire non trouvé.";
    }

    // Fermer le résultat et la connexion à la base de données
    $result->close();
    $mysqli->close();
} else {
    // Identifiants du commentaire ou du forum non spécifiés dans l'URL
    echo "Identifiants du commentaire ou du forum non spécifiés.";
}
?>
