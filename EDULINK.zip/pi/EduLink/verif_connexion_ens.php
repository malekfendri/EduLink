<?php
session_start(); // Démarrer la session
include 'sql.php';

// Vérifier le formulaire soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $identifiant = $_POST["txt"];
    $mot_de_passe = $_POST["pswd"];

    // Utiliser une requête préparée pour éviter les injections SQL
    $stmt = $mysqli->prepare("SELECT * FROM enseignant WHERE identifiant=? AND mot_de_passe=?");

    // Vérifier si la préparation de la requête a réussi
    if ($stmt) {
        // Binder les paramètres
        $stmt->bind_param("ss", $identifiant, $mot_de_passe);

        // Exécuter la requête
        $stmt->execute();

        // Récupérer le résultat
        $result = $stmt->get_result();

        // Vérifier l'authentification
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();

            // Stocker les données dans la session, y compris l'identifiant de l'enseignant
            $_SESSION['enseignant_id'] = $row['identifiant'];
            $_SESSION['enseignant_nom'] = $row['nom'];
            $_SESSION['enseignant_prenom'] = $row['prenom'];
            $_SESSION['enseignant_universite'] = $row['universite'];
            $_SESSION['enseignant_module'] = $row['module'];
            $_SESSION['enseignant_email'] = $row['email'];
            $_SESSION['enseignant_departement'] = $row['departement'];

            // Redirection vers la page de profil
            header("Location: forum.php");
            exit();
        } else {
            // Authentification échouée
            header("Location: failed.html");
            exit();
        }

        // Fermer le statement
        $stmt->close();
    } else {
        // Erreur de préparation de la requête
        die("Erreur de préparation de la requête: " . $mysqli->error);
    }
}

// Fermer la connexion à la base de données (si nécessaire)
$mysqli->close();
?>
