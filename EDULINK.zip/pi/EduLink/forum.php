<?php
// Inclure votre fichier de connexion à la base de données
include('sql.php');

// Initialiser les variables avec une valeur par défaut
$total_enseignants = 0;
$total_forums = 0;
$total_commentaires = 0;

// Effectuer la requête pour compter le nombre d'enseignants
$query_enseignants = "SELECT COUNT(*) AS total_enseignants FROM enseignant";
$result_enseignants = $mysqli->query($query_enseignants);

// Vérifier si la requête a été exécutée avec succès et si elle a renvoyé des résultats
if ($result_enseignants && $result_enseignants->num_rows > 0) {
    $row_enseignants = $result_enseignants->fetch_assoc();
    $total_enseignants = $row_enseignants['total_enseignants'];
}

// Effectuer la requête pour compter le nombre de forums
$query_forums = "SELECT COUNT(*) AS total_forums FROM forum";
$result_forums = $mysqli->query($query_forums);

// Vérifier si la requête a été exécutée avec succès et si elle a renvoyé des résultats
if ($result_forums && $result_forums->num_rows > 0) {
    $row_forums = $result_forums->fetch_assoc();
    $total_forums = $row_forums['total_forums'];
}

// Effectuer la requête pour compter le nombre de commentaires
$query_commentaires = "SELECT COUNT(*) AS total_commentaires FROM commentaire";
$result_commentaires = $mysqli->query($query_commentaires);

// Vérifier si la requête a été exécutée avec succès et si elle a renvoyé des résultats
if ($result_commentaires && $result_commentaires->num_rows > 0) {
    $row_commentaires = $result_commentaires->fetch_assoc();
    $total_commentaires = $row_commentaires['total_commentaires'];
}
// Effectuer la requête pour obtenir les types de collaborations les plus demandés par ordre décroissant
$query_collaborations = "SELECT collaboration, COUNT(*) AS total_forums FROM forum GROUP BY collaboration ORDER BY total_forums DESC ";
$result_collaborations = $mysqli->query($query_collaborations);

// Fermer la connexion à la base de données
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
  <meta charset="UTF-8" />
  <title>Forum</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Boxicons CDN Link -->
  <link
    href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css"
    rel="stylesheet"
  />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bx-link-alt'></i>         
       <span class="logo_name">EduLink</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="profil.php">
          <i class="bx bx-user"></i>
          <span class="links_name">Profil</span>
        </a>
      </li>
      <li>
        <a href="forum.php" class="active">
          <i class="bx bx-list-ul"></i>
          <span class="links_name">Forums</span>
        </a>
      </li>
      <li class="log_out">
        <a href="authentification.html">
          <i class="bx bx-log-out"></i>
          <span class="links_name">Déconnexion</span>
        </a>
      </li>
    </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class="bx bx-menu sidebarBtn"></i>
      </div>
      <div class="profile-details">
        <img src="logo_edulink.png" alt="logo">
      </div>
    </nav>
   
    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
          <div class="box-topic">Forums</div>
          <center><div class="number"><?php echo $total_forums; ?></div></center>
            <div class="indicator">
              <i class='bx bxs-conversation'></i>        
                      <span class="text">Depuis hier</span>
            </div>
          </div>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Commentaires</div>
            <center><div class="number"><?php echo $total_commentaires; ?></div></center>
            <div class="indicator">
              <i class='bx bx-message-rounded-add'></i>    
                          <span class="text">Depuis hier</span>
            </div>
          </div>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Enseignants</div>
            <center><div class="number"><?php echo $total_enseignants; ?></div></center>
            <div class="indicator">
              <i class='bx bxs-user-account'></i>          
                    <span class="text">Depuis hier</span>
            </div>
          </div>
        </div>
      </div>

      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="title">Forums Récents </div>
          <div class="sales-details">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Date</th>
                  <th>Module</th>
                  <th>Collaboration</th>
                  <th>Objet</th>
                </tr>
              </thead>
              <tbody>
                <?php
                session_start() ;
                // Include your database connection file
                include('sql.php');

                // Select recent forums
                $query = "SELECT id_forum ,date, module, collaboration, objet FROM forum ORDER BY date DESC "; // Adjust the query as needed
                $result = $mysqli->query($query);

                // Check if there are any recent forums
                if ($result && $result->num_rows > 0) {
                  while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                    <td><a href="forum_détails.php?id=<?php echo $row['id_forum']; ?>"><?php echo $row['id_forum']; ?></a></td>
                      <td><?php echo $row['date']; ?></td>
                      <td><?php echo $row['module']; ?></td>
                      <td><?php echo $row['collaboration']; ?></td>
                      <td><?php echo $row['objet']; ?></td>
                    </tr>
                    <?php
                  }
                  $result->free();
                } else {
                  ?>
                  <tr>
                    <td colspan="5">Aucun forum récent trouvé.</td>
                  </tr>
                  <?php
                }

                // Close the database connection
                $mysqli->close();
                ?>
              </tbody>
            </table>
          </div>
          <div class="button">
            <a href="ajout_forum.html">Ajouter Un forum</a>
          </div>
        </div>
        <div class="top-sales box">
          <div class="title">Types de Collaborations les plus demandés </div>
          <ul class="top-sales-details">
          <?php
            // Check if there are any collaborations
            if ($result_collaborations && $result_collaborations->num_rows > 0) {
              while ($row = $result_collaborations->fetch_assoc()) {
                ?>
                <li>
                    <span class="product"><?php echo $row['collaboration']; ?></span>
                  </a>
                  <span class="price"><?php echo $row['total_forums']; ?></span>
                </li>
                <?php
              }
              $result_collaborations->free();
            } else {
              ?>
              <li>Aucun type de collaboration trouvé.</li>
              <?php
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function () {
      sidebar.classList.toggle("active");
      if (sidebar.classList.contains("active")) {
        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
      } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    };
  </script>
</body>
</html>
