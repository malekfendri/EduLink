<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
    <meta charset="UTF-8" />
    <title>Forum Détails</title>
    <link rel="stylesheet" href="style.css" />
    <!-- Boxicons CDN Link -->
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        /* Ajout de styles CSS */
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .forum-box {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .forum-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .forum-description {
            color: #666;
            margin-bottom: 10px;

        }
        .forum-objet {
            color: #666;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .teacher-info {
            color: #888;
        }

        .commentaires {
            margin-top: 20px;
        }

        .commentaire {
            background-color: #f0f0f0;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .commentaire p {
            margin-bottom: 5px;
        }

        .commentaire span {
            color: #888;
        }
        
        /* Style du bouton "Ajouter Commentaire" */
        #submit_comment {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        #submit_comment:hover {
            background-color: #0056b3;
        }

        /* Style de la zone de saisie des commentaires */
        #commentaire {
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: vertical;
            margin-bottom: 10px;
        }

        /* Style du bouton de modification */
        .edit-comment {
            background-color: #4CAF50; /* Vert */
            border: none;
            color: white;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            margin-right: 5px;
            border-radius: 3px;
            cursor: pointer;
        }

        /* Style du bouton de suppression */
        .delete-comment {
            background-color: #f44336; /* Rouge */
            border: none;
            color: white;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            border-radius: 3px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bx-link-alt'></i>
            <span class="logo_name">EduLink</span>
        </div>
        <ul class="nav-links">
            <li>
                <a href="profil.php" >
                    <i class="bx bx-user"></i>
                    <span class="links_name">Profil</span>
                </a>
            </li>
            <li>
                <a href="forum.php" class="active">
                    <i class="bx bx-list-ul"></i>
                    <span class="links_name">Forums</span>
                </a>
            </li>
            <li class="log_out">
                <a href="authentification.html">
                    <i class="bx bx-log-out"></i>
                    <span class="links_name">Déconnexion</span>
                </a>
            </li>
        </ul>
    </div>

    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <i class="bx bx-menu sidebarBtn"></i>
            </div>
            <div class="profile-details">
                <img src="logo_edulink.png" alt="logi">
            </div>
        </nav>

        <div class="home-content">
            <?php
            // Vérifier si l'ID du forum est passé dans l'URL et si enseignant_id est défini et non vide
            if (isset($_GET['id']) && isset($_SESSION['enseignant_id']) && !empty($_SESSION['enseignant_id'])) {
                $forum_id = intval($_GET['id']);

                // Inclure le fichier de connexion à la base de données
                include('sql.php');

                // Affecter enseignant_id à une variable
                $enseignant_id = $_SESSION['enseignant_id'];

                // Requête pour récupérer les détails du forum ainsi que le nom de l'enseignant
                $query = "SELECT f.objet, f.description, f.collaboration , f.module ,  e.nom, e.prenom 
                        FROM forum AS f 
                        JOIN enseignant AS e ON f.enseignant = e.identifiant
                        WHERE f.id_forum = $forum_id";
                $result = $mysqli->query($query);

                // Vérifiez si la requête a réussi
                if ($result && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $objet = $row['objet'];
                    $module = $row['module'];
                    $collaboration = $row['collaboration'];
                    $description = $row['description'];
                    $nom_enseignant = $row['nom'];
                    $prenom_enseignant = $row['prenom'];

                    // Afficher les détails du forum dans une boîte
                    echo "<div class='forum-box'>";
                    echo "<div class='forum-title'>$objet</div>";
                    echo "<div class='forum-objet'>Module : $module</div>";
                    echo "<div class='forum-objet'>Type de collaboration : $collaboration</div>";
                    echo "<div class='forum-description'>$description</div>";
                    echo "<div class='teacher-info'>Enseignant: $nom_enseignant $prenom_enseignant</div>";
                    echo "</div>";                    
                    ?>
                    <div class="commentaires">
                        <?php
                        // Requête pour récupérer les commentaires avec les noms des enseignants correspondants
                        $query_commentaires = "SELECT c.id_commentaire, c.commentaire , c.enseignant , e.nom, e.prenom
                                                FROM commentaire AS c
                                                INNER JOIN enseignant AS e ON c.enseignant = e.identifiant
                                                WHERE c.forum = $forum_id";
                        $result_commentaires = $mysqli->query($query_commentaires);

                        // Vérifier si la requête a réussi
                        if ($result_commentaires && $result_commentaires->num_rows > 0) {
                            // Afficher les commentaires un par un avec les noms des enseignants
                            while ($row_commentaire = $result_commentaires->fetch_assoc()) {
                                $commentaire_id = $row_commentaire['id_commentaire'];
                                $commentaire = $row_commentaire['commentaire'];
                                $nom_enseignant_commentaire = $row_commentaire['nom'];
                                $prenom_enseignant_commentaire = $row_commentaire['prenom'];

                                // Vérifier si l'utilisateur actuel est l'auteur du commentaire
                                if ($enseignant_id == $row_commentaire['enseignant']) {
                                    // Affichage du commentaire avec le nom de l'enseignant et les boutons de modification et de suppression
                                    echo "<div class='commentaire'>";
                                    echo "<p><span>$nom_enseignant_commentaire $prenom_enseignant_commentaire :</span> $commentaire</p>";
                                    echo "<a href='edit_comment.php?id=$commentaire_id&forum_id=$forum_id' class='edit-comment'>Modifier</a>";
                                    echo "<a href='delete_comment.php?id=$commentaire_id&forum_id=$forum_id' class='delete-comment' onclick='return confirmDelete()'>Supprimer</a>";
                                    echo "</div>";
                                } else {
                                    // Affichage du commentaire avec le nom de l'enseignant sans les boutons de modification et de suppression
                                    echo "<div class='commentaire'>";
                                    echo "<p><span>$nom_enseignant_commentaire $prenom_enseignant_commentaire :</span> $commentaire</p>";
                                    echo "</div>";
                                }
                            }
                        } else {
                            echo "<div class='commentaire'>Aucun commentaire trouvé.</div>";
                        }

                        ?>
                    </div>
                    <?php

                    // Gérer la soumission du commentaire
                    if (isset($_POST['submit_comment'])) {
                        if (isset($_POST['commentaire']) && !empty($_POST['commentaire'])) {
                            $commentaire = $mysqli->real_escape_string($_POST['commentaire']);

                            // Requête pour insérer le commentaire 
                            $insert_query = "INSERT INTO commentaire (forum, commentaire, enseignant) VALUES ($forum_id, '$commentaire', '$enseignant_id')";
                            $insert_result = $mysqli->query($insert_query);

                            if ($insert_result) {
                                // Redirection vers la page forum_détails.php avec l'id du forum
                                echo "<script>window.location.href='forum_détails.php?id=$forum_id';</script>";
                                exit; // Assurez-vous de terminer le script après la redirection
                            } else {
                                echo "<div class='error'>Erreur lors de l'ajout du commentaire.</div>";
                            }
                        } else {
                            echo "<div class='error'>Veuillez saisir un commentaire.</div>";
                        }
                    }

                    // Afficher le formulaire de commentaire
                    echo "<div class='comment-form'>";
                    echo "<form action='' method='post'>";
                    echo "<input type='hidden' name='forum_id' value='$forum_id'>";
                    echo "<textarea name='commentaire' id='commentaire' rows='2' placeholder='Saisissez votre commentaire ici...'></textarea><br>";
                    echo "<input type='submit' name='submit_comment' id='submit_comment' value='Ajouter Commentaire'>";
                    echo "</form>";
                    echo "</div>";

                    // Fermer le résultat et la connexion à la base de données
                    $result->close();
                    $mysqli->close();
                } else {
                    echo "<div class='forum-box'>ID de forum non spécifié ou identifiant de l'enseignant non valide.</div>";
                }
            }
            ?>
        </div>
    </section>

    <!-- JavaScript pour la boîte de dialogue de confirmation -->
    <script>
        function confirmDelete() {
            return confirm("Êtes-vous sûr de vouloir supprimer ce commentaire ?");
        }
    </script>
</body>

</html>
