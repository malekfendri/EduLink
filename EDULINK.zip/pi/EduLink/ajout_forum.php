<?php
session_start();

// Inclure votre fichier de connexion à la base de données
include('sql.php');

// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les valeurs du formulaire
    $module = $_POST["module"];
    $collaboration = $_POST["collaboration-type"];
    $objet = $_POST["object"];
    $description = $_POST["description"];
    $enseignant = $_SESSION['enseignant_id'];

    // Préparer la requête SQL d'insertion
    $query = "INSERT INTO forum (enseignant , module, collaboration , objet , description  ) VALUES (?, ?, ?, ?, ?)";

    // Préparer la déclaration SQL
    $statement = $mysqli->prepare($query);

    // Lier les paramètres
    $statement->bind_param("sssss",$enseignant ,  $module, $collaboration, $objet, $description);

    // Exécuter la requête
    if ($statement->execute()) {
         header("Location: forum.php");
        exit();
    } else {
        echo "Erreur lors de la création du forum : " . $mysqli->error;
    }

    // Fermer la déclaration et la connexion à la base de données
    $statement->close();
    $mysqli->close();
}
?>
